package com.boot.techsupportscheduler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechSupportSchedulerApplication {

    public static void main(String[] args) {
        SpringApplication.run(TechSupportSchedulerApplication.class, args);
    }

}
