package com.boot.techsupportscheduler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechSupportSchedulerApplicationTests {

    @Test
    void contextLoads() {
    }

}
